import { PipelineUI } from "./ui";

const App = () => {
  return <PipelineUI />;
};

export default App;
